# By importing this module, all handlers defined there will get registered to
# be used in the HandlerRegistry
from aoc_solver.terminal import handlers  # pylint: disable=unused-import
